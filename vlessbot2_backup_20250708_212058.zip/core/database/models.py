from sqlalchemy import Column, Integer, String, BigInteger, DateTime, Boolean, ForeignKey
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.sql import func

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String, nullable=True)
    language_code = Column(String, default='ru')
    referral_balance = Column(Integer, default=0)
    referrer_id = Column(BigInteger, ForeignKey('users.telegram_id'), nullable=True)
    created_at = Column(DateTime, default=func.now())
    trial_used = Column(Boolean, default=False, nullable=False)
    unassigned_days = Column(Integer, default=0)
    bonus_days = Column(Integer, default=0)
    total_paid_out = Column(Integer, default=0)

    def __repr__(self):
        return f"<User(id={self.id}, telegram_id={self.telegram_id}, username='{self.username}')>"


class Server(Base):
    __tablename__ = 'servers'

    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    api_url = Column(String, nullable=False)
    api_user = Column(String, nullable=False)
    api_password = Column(String, nullable=False) # TODO: Encrypt this
    inbound_id = Column(Integer, nullable=False)
    is_active = Column(Boolean, default=True)

    def __repr__(self):
        return f"<Server(id={self.id}, name='{self.name}')>"


class Tariff(Base):
    __tablename__ = 'tariffs'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    duration_days = Column(Integer, nullable=False)
    price_rub = Column(Integer, nullable=False)
    price_stars = Column(Integer, nullable=False)
    is_active = Column(Boolean, default=True)

    def __repr__(self):
        return f"<Tariff(id={self.id}, name='{self.name}')>"


class Subscription(Base):
    __tablename__ = 'subscriptions'

    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.telegram_id'), nullable=False)
    server_id = Column(Integer, ForeignKey('servers.id'), nullable=False)
    xui_user_uuid = Column(String, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f"<Subscription(id={self.id}, user_id={self.user_id}, server_id={self.server_id})>"


class Transaction(Base):
    __tablename__ = 'transactions'

    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, ForeignKey('users.telegram_id'), nullable=False)
    tariff_id = Column(Integer, ForeignKey('tariffs.id'), nullable=True)
    amount = Column(Integer, nullable=False)
    currency = Column(String, nullable=False)
    payment_system = Column(String, nullable=False)
    status = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now())

    def __repr__(self):
        return f"<Transaction(id={self.id}, user_id={self.user_id}, amount={self.amount}, status='{self.status}')>"