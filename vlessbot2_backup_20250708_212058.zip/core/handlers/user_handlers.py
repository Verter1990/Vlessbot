from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, LabeledPrice, PreCheckoutQuery, SuccessfulPayment
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from core.database.models import Server, Subscription, User, Tariff
from core.services.xui_client import xui_client, XUIClientError
from core.config import settings
import uuid
from datetime import datetime, timedelta
from urllib.parse import urlparse

router = Router()

# Helper function to create or update VPN key for a specific server
async def _create_or_update_vpn_key(session: AsyncSession, user: User, server: Server, days: int):
    logger.info(f"Creating/updating VPN key for user {user.telegram_id} on server {server.name} for {days} days.")
    
    existing_subscription = await session.execute(
        select(Subscription).where(
            Subscription.user_id == user.telegram_id,
            Subscription.server_id == server.id
        )
    )
    existing_subscription = existing_subscription.scalars().first()

    user_uuid = None
    expire_time = datetime.utcnow() + timedelta(days=days)
    expire_time_ms = int(expire_time.timestamp() * 1000)

    try:
        if existing_subscription:
            user_uuid = existing_subscription.xui_user_uuid
            logger.info(f"Updating existing client {user_uuid} on XUI for user {user.telegram_id}")
            await xui_client.update_client(server.inbound_id, user_uuid, expire_time_ms)
            existing_subscription.expires_at = expire_time
            existing_subscription.is_active = True
            await session.commit()
            logger.info(f"Updated subscription for user {user.telegram_id} on server {server.name}")
        else:
            user_uuid = str(uuid.uuid4())
            logger.info(f"Creating new client {user_uuid} on XUI for user {user.telegram_id}")
            await xui_client.create_user(
                inbound_id=server.inbound_id,
                uuid=user_uuid,
                email=str(user.telegram_id),
                expire_time_ms=expire_time_ms,
                telegram_id=str(user.telegram_id)
            )
            new_subscription = Subscription(
                user_id=user.telegram_id,
                server_id=server.id,
                xui_user_uuid=user_uuid,
                expires_at=expire_time,
                is_active=True
            )
            session.add(new_subscription)
            await session.commit()
            logger.info(f"Created new subscription for user {user.telegram_id} on server {server.name}")

        inbound = await xui_client.get_inbound(server.inbound_id)
        if not inbound:
            raise XUIClientError("Inbound not found for link generation")

        settings_data = inbound.get("settings", {})
        params_list = []
        if "security" in settings_data:
            params_list.append(f"security={settings_data['security']}")
        if "encryption" in settings_data:
            params_list.append(f"encryption={settings_data['encryption']}")
        if "type" in settings_data:
            params_list.append(f"type={settings_data['type']}")
        params = "&".join(params_list) if params_list else "security=tls&encryption=none&type=tcp"

        parsed_url = urlparse(server.api_url)
        host = parsed_url.hostname
        port = parsed_url.port or 443
        vless_link = f"vless://{user_uuid}@{host}:{port}?{params}#VPN_{server.name}"
        
        return vless_link

    except XUIClientError as e:
        logger.error(f"XUIClientError while creating/updating key for user {user.telegram_id}: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error while creating/updating key for user {user.telegram_id}: {e}")
        raise

@router.message(Command("start"))
async def command_start_handler(message: Message, session: AsyncSession) -> None:
    logger.info(f"User {message.from_user.id} sent /start")
    
    stmt = select(User).where(User.telegram_id == message.from_user.id)
    result = await session.execute(stmt)
    user = result.scalars().first()
    if not user:
        logger.info(f"User {message.from_user.id} not found in DB, adding new user.")
        user = User(telegram_id=message.from_user.id, username=message.from_user.username)
        session.add(user)
        await session.commit()
        logger.info(f"New user {message.from_user.id} added to the database.")

    welcome_message = f"Привет, {message.from_user.full_name}! Это главное меню."
    # Check for active subscriptions in the Subscription table
    now = datetime.utcnow()
    active_subscriptions = await session.execute(
        select(Subscription).where(
            Subscription.user_id == user.telegram_id,
            Subscription.expires_at > now,
            Subscription.is_active == True
        )
    )
    active_subscriptions = active_subscriptions.scalars().all()

    if active_subscriptions:
        # Find the latest expiring subscription to display
        latest_expiry = max([sub.expires_at for sub in active_subscriptions])
        welcome_message += f"\n\nВаша подписка активна до: **{latest_expiry.strftime('%Y-%m-%d %H:%M')}**"
    else:
        welcome_message += "\n\nУ вас пока нет активной подписки."

    if user.unassigned_days > 0:
        welcome_message += f"\n\nУ вас есть **{user.unassigned_days}** неиспользованных дней VPN-доступа."

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Настроить VPN", callback_data="setup_vpn")],
        [InlineKeyboardButton(text="Оплатить подписку", callback_data="pay_subscription_main_menu")], # Changed callback_data
        [InlineKeyboardButton(text="Пригласить друга", callback_data="invite_friend")],
        [InlineKeyboardButton(text="Чем лучше наш VPN?", callback_data="why_vpn")],
        [InlineKeyboardButton(text="Добавить email", callback_data="add_email")],
        [InlineKeyboardButton(text="Получить бесплатный VPN на 3 дня", callback_data="get_free_vpn")],
        [InlineKeyboardButton(text="Нужна помощь?", callback_data="help")],
        [InlineKeyboardButton(text="Правила использования", callback_data="terms_of_use")]
    ])
    await message.answer(welcome_message, reply_markup=keyboard)

@router.callback_query(F.data == "setup_vpn")
async def callback_setup_vpn(callback: CallbackQuery, session: AsyncSession) -> None:
    logger.info(f"User {callback.from_user.id} clicked setup_vpn")
    await callback.answer()

    try:
        stmt = select(Server).where(Server.is_active == True)
        result = await session.execute(stmt)
        servers = result.scalars().all()
    except Exception as e:
        logger.error(f"Error querying servers: {e}")
        await callback.message.answer("Произошла ошибка при получении серверов. Попробуйте позже.")
        return

    if not servers:
        await callback.message.answer("Извините, в данный момент нет доступных серверов.")
        return

    buttons = [[InlineKeyboardButton(text=server.name, callback_data=f"select_server_{server.id}")] for server in servers]
    buttons.append([InlineKeyboardButton(text="Главное меню", callback_data="main_menu")]) # Add Main Menu button
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
    
    await callback.message.edit_text("Выберите сервер для настройки:", reply_markup=keyboard)

@router.callback_query(F.data.startswith("select_server_"))
async def callback_select_server(callback: CallbackQuery, session: AsyncSession) -> None:
    logger.info(f"User {callback.from_user.id} selected server via callback: {callback.data}")
    await callback.answer()
    
    server_id = int(callback.data.split("_")[-1])
    
    stmt = select(User).where(User.telegram_id == callback.from_user.id)
    result = await session.execute(stmt)
    user = result.scalars().first()
    selected_server = await session.get(Server, server_id)

    if not user or not selected_server:
        await callback.message.answer("Произошла ошибка. Пользователь или сервер не найден.")
        return

    # Check for active subscription for this specific server
    now = datetime.utcnow()
    existing_subscription = await session.execute(
        select(Subscription).where(
            Subscription.user_id == user.telegram_id,
            Subscription.server_id == selected_server.id,
            Subscription.expires_at > now,
            Subscription.is_active == True
        )
    )
    existing_subscription = existing_subscription.scalars().first()

    if existing_subscription:
        logger.info(f"Active subscription found for user {user.telegram_id} on server {selected_server.name}. Showing key.")
        try:
            inbound = await xui_client.get_inbound(selected_server.inbound_id)
            if not inbound:
                raise XUIClientError("Inbound not found for link generation")

            settings_data = inbound.get("settings", {})
            params_list = []
            if "security" in settings_data:
                params_list.append(f"security={settings_data['security']}")
            if "encryption" in settings_data:
                params_list.append(f"encryption={settings_data['encryption']}")
            if "type" in settings_data:
                params_list.append(f"type={settings_data['type']}")
            params = "&".join(params_list) if params_list else "security=tls&encryption=none&type=tcp"

            parsed_url = urlparse(selected_server.api_url)
            host = parsed_url.hostname
            port = parsed_url.port or 443

            vless_link = f"vless://{existing_subscription.xui_user_uuid}@{host}:{port}?{params}#VPN_{selected_server.name}"
            await callback.message.answer(f"У вас уже есть активная подписка на {selected_server.name}.\nВаш ключ VPN: `{vless_link}`\nСрок действия до: {existing_subscription.expires_at.strftime('%Y-%m-%d %H:%M')}")

        except Exception as e:
            logger.error(f"Unexpected error showing subscription: {e}")
            await callback.message.answer("Произошла непредвиденная ошибка при отображении вашей подписки. Пожалуйста, попробуйте позже.")
        return

    # If no active subscription for this server, check unassigned_days
    if user.unassigned_days > 0:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=f"Да, активировать {user.unassigned_days} дней", callback_data=f"activate_unassigned_days_{selected_server.id}")],
            [InlineKeyboardButton(text="Нет, выбрать другой тариф", callback_data=f"pay_subscription_for_server_{selected_server.id}")]
        ])
        await callback.message.edit_text(
            f"У вас есть **{user.unassigned_days}** неиспользованных дней VPN-доступа.\n\n"
            f"Хотите активировать их для сервера **{selected_server.name}**?",
            reply_markup=keyboard
        )
    else:
        # If no unassigned_days, directly offer tariffs for this server
        await callback.message.edit_text(f"У вас нет активной подписки на {selected_server.name}. Пожалуйста, выберите тариф для оплаты.")
        await callback_pay_subscription(callback, session, selected_server.id) # Pass server_id to pay_subscription

@router.callback_query(F.data.startswith("activate_unassigned_days_"))
async def activate_unassigned_days(callback: CallbackQuery, session: AsyncSession):
    logger.info(f"User {callback.from_user.id} chose to activate unassigned days.")
    await callback.answer()

    server_id = int(callback.data.split("_")[-1])

    stmt = select(User).where(User.telegram_id == callback.from_user.id)
    result = await session.execute(stmt)
    user = result.scalars().first()
    selected_server = await session.get(Server, server_id)

    if not user or not selected_server:
        await callback.message.answer("Произошла ошибка. Пользователь или сервер не найден.")
        return

    if user.unassigned_days <= 0:
        await callback.message.answer("У вас нет неиспользованных дней для активации.")
        return

    try:
        vless_link = await _create_or_update_vpn_key(session, user, selected_server, user.unassigned_days)
        user.unassigned_days = 0 # Reset unassigned days after activation
        await session.commit()

        await callback.message.answer(
            f"✅ Ваши неиспользованные дни активированы для сервера **{selected_server.name}**!\n\n"
            f"Ваш ключ VPN: `{vless_link}`\n\n"
            f"Инструкции по подключению: ..."
        )
    except Exception as e:
        logger.error(f"Error activating unassigned days for user {user.telegram_id}: {e}")
        await callback.message.answer("Произошла ошибка при активации дней. Пожалуйста, попробуйте позже.")


@router.callback_query(F.data == "pay_subscription_main_menu") # New callback_data for main menu button
@router.callback_query(F.data.startswith("pay_subscription_for_server_")) # New callback_data for server-specific payment
async def callback_pay_subscription(callback: CallbackQuery, session: AsyncSession, server_id: int = None):
    logger.info(f"User {callback.from_user.id} clicked pay_subscription")
    await callback.answer()

    if callback.data.startswith("pay_subscription_for_server_"):
        server_id = int(callback.data.split("_")[-1])

    try:
        stmt = select(Tariff).where(Tariff.is_active == True).order_by(Tariff.duration_days)
        result = await session.execute(stmt)
        tariffs = result.scalars().all()
    except Exception as e:
        logger.error(f"Error querying tariffs: {e}")
        await callback.message.answer("Произошла ошибка при получении тарифов. Попробуйте позже.")
        return

    if not tariffs:
        await callback.message.answer("Извините, в данный момент нет доступных тарифов.")
        return

    buttons = [[InlineKeyboardButton(text=f"{tariff.name} - {tariff.price_rub/100}₽ / {tariff.price_stars}*", callback_data=f"select_tariff_{tariff.id}_{server_id if server_id else 'none'}")] for tariff in tariffs]
    buttons.append([InlineKeyboardButton(text="Главное меню", callback_data="main_menu")]) # Add Main Menu button
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
    
    await callback.message.edit_text("Выберите тариф:", reply_markup=keyboard)

@router.callback_query(F.data.startswith("select_tariff_"))
async def process_tariff_selection(callback: CallbackQuery, session: AsyncSession):
    parts = callback.data.split("_")
    tariff_id = int(parts[2])
    server_id = int(parts[3]) if len(parts) > 3 and parts[3] != 'none' else None # Get server_id from callback_data
    user_id = callback.from_user.id
    logger.info(f"User {user_id} selected tariff {tariff_id} for server {server_id}. Showing payment options.")

    tariff = await session.get(Tariff, tariff_id)
    if not tariff:
        await callback.message.answer("Произошла ошибка. Тариф не найден.")
        await callback.answer()
        return

    # Generate payment options keyboard
    buttons = [
        [InlineKeyboardButton(text=f"Оплатить {tariff.price_rub/100:.2f} ₽ (Картой)", callback_data=f"pay_card_{tariff.id}_{server_id if server_id else 'none'}")],
        [InlineKeyboardButton(text=f"Оплатить {tariff.price_stars} ⭐️", callback_data=f"pay_stars_{tariff.id}_{server_id if server_id else 'none'}")],
        [InlineKeyboardButton(text="Оплата переводом", callback_data=f"pay_transfer_{tariff.id}_{server_id if server_id else 'none'}")],
    ]
    if tariff.duration_days >= 365: # Only show crypto for yearly tariff
        buttons.append([InlineKeyboardButton(text="Оплатить криптовалютой", callback_data=f"pay_crypto_{tariff.id}_{server_id if server_id else 'none'}")])
    
    buttons.append([InlineKeyboardButton(text="Выбор тарифа", callback_data=f"pay_subscription_for_server_{server_id}")]) # Back to tariff selection for this server
    buttons.append([InlineKeyboardButton(text="Главное меню", callback_data="main_menu")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)

    await callback.message.edit_text(
        f"<b>{tariff.name}</b> - {tariff.price_rub/100:.2f} ₽ за доступ к премиум версии сроком на {tariff.duration_days} дней.\n\n"
        f"Пожалуйста, выберите способ оплаты:",
        reply_markup=keyboard
    )
    await callback.answer()

@router.callback_query(F.data.startswith("pay_crypto_"))
async def callback_pay_crypto(callback: CallbackQuery, session: AsyncSession):
    parts = callback.data.split("_")
    tariff_id = int(parts[2])
    server_id = int(parts[3]) if len(parts) > 3 and parts[3] != 'none' else None # Get server_id

    tariff = await session.get(Tariff, tariff_id)
    if not tariff:
        await callback.message.answer("Произошла ошибка. Тариф не найден.")
        await callback.answer()
        return

    text = (
        f"Оплата криптовалютой доступна только на год со скидкой 25%!\n\n"
        f"Оплатите на один из кошельков <b>{settings.CRYPTO_YEARLY_PRICE_USD} USD</b> (или эквивалент в крипте):\n\n"
        f"BTC: <code>{settings.CRYPTO_BTC_ADDRESS}</code>\n"
        f"ETH (ERC-20): <code>{settings.CRYPTO_ETH_ADDRESS}</code>\n"
        f"USDT (TRC-20): <code>{settings.CRYPTO_USDT_TRC20_ADDRESS}</code>\n\n"
        f"И пришлите ссылку на транзакцию или чек к нам в службу поддержки ⬇️"
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Отправить чек в техподдержку", url=settings.SUPPORT_CHAT_LINK)],
        [InlineKeyboardButton(text="Назад", callback_data=f"select_tariff_{tariff_id}_{server_id if server_id else 'none'}")] # Pass server_id back
    ])
    await callback.message.edit_text(text, reply_markup=keyboard, disable_web_page_preview=True)
    await callback.answer()


@router.callback_query(F.data.startswith("pay_stars_"))
async def callback_pay_stars(callback: CallbackQuery, session: AsyncSession):
    parts = callback.data.split("_")
    tariff_id = int(parts[2])
    server_id = int(parts[3]) if len(parts) > 3 and parts[3] != 'none' else None # Get server_id
    user_id = callback.from_user.id
    logger.info(f"User {user_id} selected tariff {tariff_id} for server {server_id} for Stars payment.")

    tariff = await session.get(Tariff, tariff_id)
    if not tariff:
        await callback.message.answer("Произошла ошибка. Тариф не найден.")
        await callback.answer()
        return

    if not settings.TELEGRAM_PAYMENT_PROVIDER_TOKEN or settings.TELEGRAM_PAYMENT_PROVIDER_TOKEN == "YOUR_TELEGRAM_PAYMENT_PROVIDER_TOKEN":
        await callback.message.answer("Извините, оплата звездами в данный момент недоступна.")
        logger.warning("Telegram Stars payment attempted but no provider token is set.")
        await callback.answer()
        return

    payload = f"stars_{user_id}_{tariff.id}_{server_id if server_id else 'none'}" # Pass server_id in payload
    
    await callback.bot.send_invoice(
        chat_id=callback.from_user.id,
        title=f"Подписка: {tariff.name}",
        description=f"Доступ к VPN на {tariff.duration_days} дней.",
        payload=payload,
        provider_token=settings.TELEGRAM_PAYMENT_PROVIDER_TOKEN,
        currency="XTR",
        prices=[LabeledPrice(label=f"{tariff.name} ({tariff.duration_days} дней)", amount=tariff.price_stars)],
    )
    await callback.answer()

@router.pre_checkout_query()
async def pre_checkout_query_handler(pre_checkout_query: PreCheckoutQuery, session: AsyncSession):
    logger.info(f"Received pre-checkout query from {pre_checkout_query.from_user.id} with payload {pre_checkout_query.invoice_payload}")
    await pre_checkout_query.answer(ok=True)

@router.message(F.successful_payment)
async def successful_payment_handler(message: Message, session: AsyncSession):
    logger.info(f"Received successful payment from {message.from_user.id}. Payload: {message.successful_payment.invoice_payload}")
    
    payload = message.successful_payment.invoice_payload
    parts = payload.split('_')
    
    if not (len(parts) == 4 and parts[0] == 'stars'): # Changed from 3 to 4 parts
        logger.warning(f"Received successful payment with invalid payload: {payload}")
        return

    try:
        user_telegram_id = int(parts[1])
        tariff_id = int(parts[2])
        server_id = int(parts[3]) if parts[3] != 'none' else None # Get server_id from payload
    except (ValueError, IndexError):
        logger.error(f"Could not parse payload: {payload}")
        return

    stmt = select(User).where(User.telegram_id == user_telegram_id)
    result = await session.execute(stmt)
    user = result.scalars().first()
    
    tariff = await session.get(Tariff, tariff_id)

    if not all([user, tariff]):
        logger.error(f"Could not find user or tariff for payload: {payload}")
        await message.answer("Произошла ошибка при обработке вашего платежа. Пожалуйста, свяжитесь с поддержкой.")
        return

    logger.info(f"Processing successful payment for user {user.telegram_id}, tariff {tariff.name}")

    # If server_id is provided, create/update subscription for that specific server
    if server_id:
        server = await session.get(Server, server_id)
        if not server:
            logger.error(f"Server {server_id} not found for successful payment payload: {payload}")
            await message.answer("Произошла ошибка при обработке вашего платежа (сервер не найден). Пожалуйста, свяжитесь с поддержкой.")
            return
        
        try:
            vless_link = await _create_or_update_vpn_key(session, user, server, tariff.duration_days)
            await message.answer(
                f"✅ Оплата прошла успешно!\n\n"
                f"Ваш ключ для сервера **{server.name}** готов:\n"
                f"`{vless_link}`\n\n"
                f"Он будет действовать **{tariff.duration_days}** дней.\n\n"
                f"Инструкции по подключению: ..."
            )
        except Exception as e:
            logger.error(f"Error creating VPN key after successful payment for payload {payload}: {e}", exc_info=True)
            await message.answer("К сожалению, произошла ошибка при создании вашего VPN ключа после оплаты. Пожалуйста, свяжитесь с поддержкой, мы все решим.")
    else:
        # This is the case for general balance top-up
        now = datetime.utcnow()
        user.unassigned_days += tariff.duration_days
        await session.commit()

        await message.answer(
            f"✅ Оплата прошла успешно!\n\n"
            f"На ваш баланс зачислено **{tariff.duration_days}** неиспользованных дней VPN-доступа.\n\n"
            f"Теперь вы можете перейти в раздел \"Настроить VPN\" и выбрать любой сервер для получения ключа.\n\n"
            f"Инструкции по подключению: ..."
        )

    # TODO: Add a button to go to setup_vpn or main menu


@router.callback_query(F.data == "get_free_vpn")
async def callback_get_free_vpn(callback: CallbackQuery, session: AsyncSession):
    logger.info(f"User {callback.from_user.id} clicked get_free_vpn")
    await callback.answer()

    stmt = select(User).where(User.telegram_id == callback.from_user.id)
    result = await session.execute(stmt)
    user = result.scalars().first()

    if user.trial_used:
        await callback.message.answer("Вы уже использовали свой бесплатный пробный период. Чтобы продолжить пользоваться сервисом, пожалуйста, оформите подписку.")
        return

    if not settings.TRIAL_SERVER_ID:
        await callback.message.answer("Извините, пробный период временно недоступен. Пожалуйста, попробуйте позже.")
        return

    trial_server = await session.get(Server, settings.TRIAL_SERVER_ID)
    if not trial_server or not trial_server.is_active:
        await callback.message.answer("Извините, пробный сервер временно недоступен. Пожалуйста, попробуйте позже.")
        return

    await callback.message.edit_text("Пожалуйста, подождите, мы создаем для вас пробный ключ...")

    try:
        # For trial, we create a specific subscription entry
        vless_link = await _create_or_update_vpn_key(session, user, trial_server, 3)
        user.trial_used = True
        await session.commit()
        await callback.message.answer(f"Ваш пробный ключ на 3 дня: {vless_link}\n\nИнструкции по подключению: ...")
    except Exception as e:
        logger.error(f"Error creating trial VPN key: {e}")
        await callback.message.answer("Произошла ошибка при создании пробного ключа. Обратитесь в поддержку.")

# --- Placeholder Handlers ---

@router.callback_query(F.data == "invite_friend")
async def callback_invite_friend(callback: CallbackQuery):
    logger.info(f"User {callback.from_user.id} clicked invite_friend")
    await callback.message.answer("Вы нажали 'Пригласить друга'.")
    await callback.answer()

@router.callback_query(F.data == "why_vpn")
async def callback_why_vpn(callback: CallbackQuery):
    logger.info(f"User {callback.from_user.id} clicked why_vpn")
    await callback.message.answer("Вы нажали 'Чем лучше наш VPN?'.")
    await callback.answer()

@router.callback_query(F.data == "add_email")
async def callback_add_email(callback: CallbackQuery):
    logger.info(f"User {callback.from_user.id} clicked add_email")
    await callback.message.answer("Вы нажали 'Добавить email'.")
    await callback.answer()

@router.callback_query(F.data == "help")
async def callback_help(callback: CallbackQuery):
    logger.info(f"User {callback.from_user.id} clicked help")
    await callback.message.answer("Вы нажали 'Нужна помощь?'.")
    await callback.answer()

@router.callback_query(F.data == "terms_of_use")
async def callback_terms_of_use(callback: CallbackQuery):
    logger.info(f"User {callback.from_user.id} clicked terms_of_use")
    await callback.message.answer("Вы нажали 'Правила использования'.")
    await callback.answer()

@router.callback_query(F.data.startswith("pay_card_"))
async def callback_pay_card(callback: CallbackQuery):
    await callback.message.answer("Оплата картой временно недоступна.")
    await callback.answer()

@router.callback_query(F.data.startswith("pay_transfer_"))
async def callback_pay_transfer(callback: CallbackQuery):
    await callback.message.answer("Оплата переводом временно недоступна.")
    await callback.answer()

@router.callback_query(F.data == "main_menu")
async def callback_main_menu(callback: CallbackQuery, session: AsyncSession):
    await callback.answer()
    await command_start_handler(callback.message, session) # Re-use start handler to show main menu
