# core/handlers/admin_handlers.py

from aiogram import Router, F, Bot
from aiogram.filters import Command, BaseFilter, CommandObject
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from loguru import logger

from core.database.models import Server, Tariff
from core.config import settings

# Фильтр для проверки, является ли пользователь администратором
class IsAdmin(BaseFilter):
    async def __call__(self, message: Message) -> bool:
        admin_ids = [int(admin_id.strip()) for admin_id in settings.ADMIN_IDS.split(',')]
        return message.from_user.id in admin_ids

# Состояния для добавления сущностей
class AddServer(StatesGroup):
    name = State()
    api_url = State()
    api_user = State()
    api_password = State()
    inbound_id = State()

class AddTariff(StatesGroup):
    name = State()
    duration_days = State()
    price_rub = State()
    price_stars = State()

router = Router()
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())

# --- Админ-панель --- #
@router.message(Command("admin"))
async def cmd_admin_panel(message: Message):
    logger.info(f"Admin {message.from_user.id} accessed the admin panel.")
    await message.answer(
        "<b>Панель администратора</b>\n\n"
        "<b>Управление серверами:</b>\n"
        "/list_servers - Показать все серверы\n"
        "/add_server - Добавить новый сервер\n"
        "/toggle_server [ID] - Вкл/Выкл сервер\n\n"
        "<b>Управление тарифами:</b>\n"
        "/list_tariffs - Показать все тарифы\n"
        "/add_tariff - Добавить новый тариф\n"
        "/toggle_tariff [ID] - Вкл/Выкл тариф\n"
    )

# --- Отмена FSM ---
@router.message(Command("cancel"))
async def cancel_handler(message: Message, state: FSMContext):
    current_state = await state.get_state()
    if current_state is None:
        return
    logger.info(f"Admin {message.from_user.id} cancelled state {current_state}")
    await state.clear()
    await message.answer("Действие отменено.")

# --- Управление серверами --- #
@router.message(Command("list_servers"))
async def cmd_list_servers(message: Message, session: AsyncSession):
    logger.info(f"Admin {message.from_user.id} requested server list.")
    servers = (await session.execute(select(Server).order_by(Server.id))).scalars().all()
    if not servers:
        await message.answer("В базе данных нет ни одного сервера.")
        return
    response_text = "<b>Список серверов:</b>\n\n"
    for server in servers:
        status = "✅ Активен" if server.is_active else "❌ Отключен"
        response_text += f"ID: <code>{server.id}</code> | {server.name} | {status}\n"
        response_text += f"   <pre>URL: {server.api_url} | Inbound: {server.inbound_id}</pre>\n"
    await message.answer(response_text, parse_mode="HTML")

@router.message(Command("toggle_server"))
async def cmd_toggle_server(message: Message, command: CommandObject, session: AsyncSession):
    logger.info(f"Admin {message.from_user.id} requested to toggle a server.")
    if not command.args or not command.args.isdigit():
        await message.answer("Ошибка: Укажите ID сервера. Пример: <code>/toggle_server 1</code>")
        return
    server_id = int(command.args)
    server = await session.get(Server, server_id)
    if not server:
        await message.answer(f"Сервер с ID <code>{server_id}</code> не найден.")
        return
    server.is_active = not server.is_active
    await session.commit()
    status = "✅ Активен" if server.is_active else "❌ Отключен"
    logger.info(f"Server {server_id} state changed to {status}")
    await message.answer(f"Статус сервера <b>{server.name}</b> (ID: {server_id}) изменен на: {status}")

@router.message(Command("add_server"))
async def cmd_add_server_start(message: Message, state: FSMContext):
    logger.info(f"Admin {message.from_user.id} started adding a new server.")
    await state.set_state(AddServer.name)
    await message.answer("<b>Добавление нового сервера</b>\n\nШаг 1/5: Введите название (напр. 🇩🇪 Германия).\nДля отмены: /cancel")

@router.message(AddServer.name)
async def process_server_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text)
    await state.set_state(AddServer.api_url)
    await message.answer("Шаг 2/5: Введите URL для API 3x-ui (напр. <code>https://your.domain:2053</code>)")

@router.message(AddServer.api_url)
async def process_server_api_url(message: Message, state: FSMContext):
    await state.update_data(api_url=message.text.rstrip('/'))
    await state.set_state(AddServer.api_user)
    await message.answer("Шаг 3/5: Введите имя пользователя API (обычно <code>admin</code>)")

@router.message(AddServer.api_user)
async def process_server_api_user(message: Message, state: FSMContext):
    await state.update_data(api_user=message.text)
    await state.set_state(AddServer.api_password)
    await message.answer("Шаг 4/5: Введите пароль для API")

@router.message(AddServer.api_password)
async def process_server_api_password(message: Message, state: FSMContext):
    await state.update_data(api_password=message.text)
    await state.set_state(AddServer.inbound_id)
    await message.answer("Шаг 5/5: Введите ID входящего подключения (Inbound ID)")

@router.message(AddServer.inbound_id)
async def process_server_inbound_id(message: Message, state: FSMContext, session: AsyncSession):
    if not message.text.isdigit():
        await message.answer("Ошибка: ID должен быть числом. Попробуйте еще раз.")
        return
    data = await state.update_data(inbound_id=int(message.text))
    await state.clear()
    try:
        session.add(Server(**data))
        await session.commit()
        logger.info(f"Admin {message.from_user.id} successfully added new server: {data['name']}")
        await message.answer(f"✅ Сервер <b>{data['name']}</b> успешно добавлен!", parse_mode="HTML")
    except Exception as e:
        logger.error(f"Could not add new server to DB. Data: {data}. Error: {e}")
        await message.answer("Произошла ошибка при добавлении сервера. Подробности в логах.")

# --- Управление тарифами ---
@router.message(Command("list_tariffs"))
async def cmd_list_tariffs(message: Message, session: AsyncSession):
    logger.info(f"Admin {message.from_user.id} requested tariff list.")
    tariffs = (await session.execute(select(Tariff).order_by(Tariff.id))).scalars().all()
    if not tariffs:
        await message.answer("В базе данных нет ни одного тарифа.")
        return
    response_text = "<b>Список тарифов:</b>\n\n"
    for tariff in tariffs:
        status = "✅ Активен" if tariff.is_active else "❌ Отключен"
        response_text += f"ID: <code>{tariff.id}</code> | {tariff.name} | {status}\n"
        response_text += f"   <pre>Длительность: {tariff.duration_days} дней</pre>\n"
        response_text += f"   <pre>Цена: {tariff.price_rub / 100} RUB | {tariff.price_stars} Stars</pre>\n"
    await message.answer(response_text, parse_mode="HTML")

@router.message(Command("toggle_tariff"))
async def cmd_toggle_tariff(message: Message, command: CommandObject, session: AsyncSession):
    logger.info(f"Admin {message.from_user.id} requested to toggle a tariff.")
    if not command.args or not command.args.isdigit():
        await message.answer("Ошибка: Укажите ID тарифа. Пример: <code>/toggle_tariff 1</code>")
        return
    tariff_id = int(command.args)
    tariff = await session.get(Tariff, tariff_id)
    if not tariff:
        await message.answer(f"Тариф с ID <code>{tariff_id}</code> не найден.")
        return
    tariff.is_active = not tariff.is_active
    await session.commit()
    status = "✅ Активен" if tariff.is_active else "❌ Отключен"
    logger.info(f"Tariff {tariff_id} state changed to {status}")
    await message.answer(f"Статус тарифа <b>{tariff.name}</b> (ID: {tariff_id}) изменен на: {status}")

@router.message(Command("add_tariff"))
async def cmd_add_tariff_start(message: Message, state: FSMContext):
    logger.info(f"Admin {message.from_user.id} started adding a new tariff.")
    await state.set_state(AddTariff.name)
    await message.answer("<b>Добавление нового тарифа</b>\n\nШаг 1/4: Введите название (напр. Месяц).\nДля отмены: /cancel")

@router.message(AddTariff.name)
async def process_tariff_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text)
    await state.set_state(AddTariff.duration_days)
    await message.answer("Шаг 2/4: Введите длительность тарифа в днях (напр. 30)")

@router.message(AddTariff.duration_days)
async def process_tariff_duration(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("Ошибка: Длительность должна быть числом. Попробуйте еще раз.")
        return
    await state.update_data(duration_days=int(message.text))
    await state.set_state(AddTariff.price_rub)
    await message.answer("Шаг 3/4: Введите цену в копейках (напр. 9900 для 99 RUB)")

@router.message(AddTariff.price_rub)
async def process_tariff_price_rub(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("Ошибка: Цена должна быть числом. Попробуйте еще раз.")
        return
    await state.update_data(price_rub=int(message.text))
    await state.set_state(AddTariff.price_stars)
    await message.answer("Шаг 4/4: Введите цену в Telegram Stars (напр. 66)")

@router.message(AddTariff.price_stars)
async def process_tariff_price_stars(message: Message, state: FSMContext, session: AsyncSession):
    if not message.text.isdigit():
        await message.answer("Ошибка: Цена в звездах должна быть числом. Попробуйте еще раз.")
        return
    data = await state.update_data(price_stars=int(message.text))
    await state.clear()
    try:
        session.add(Tariff(**data))
        await session.commit()
        logger.info(f"Admin {message.from_user.id} successfully added new tariff: {data['name']}")
        await message.answer(f"✅ Тариф <b>{data['name']}</b> успешно добавлен!", parse_mode="HTML")
    except Exception as e:
        logger.error(f"Could not add new tariff to DB. Data: {data}. Error: {e}")
        await message.answer("Произошла ошибка при добавлении тарифа. Подробности в логах.")
