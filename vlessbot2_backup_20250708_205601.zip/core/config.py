from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from typing import List, Optional

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    BOT_TOKEN: str
    DB_URL: str
    ADMIN_IDS: str

    YOOKASSA_SHOP_ID: Optional[str] = None
    YOOKASSA_SECRET_KEY: Optional[str] = None

    CLOUDPAYMENTS_PUBLIC_ID: Optional[str] = None
    CLOUDPAYMENTS_API_SECRET: Optional[str] = None

    TELEGRAM_PAYMENT_PROVIDER_TOKEN: Optional[str] = None

    XUI_API_URL: str
    XUI_API_USER: str
    XUI_API_PASSWORD: str

    SUPPORT_CHAT_LINK: Optional[str] = None
    VPN_INFO_POST_URL: Optional[str] = None
    TERMS_OF_SERVICE_URL: Optional[str] = None

    TRIAL_SERVER_ID: Optional[int] = None

    CRYPTO_YEARLY_PRICE_USD: Optional[int] = None
    CRYPTO_BTC_ADDRESS: Optional[str] = None
    CRYPTO_ETH_ADDRESS: Optional[str] = None
    CRYPTO_USDT_TRC20_ADDRESS: Optional[str] = None

settings = Settings()